---
type: technique
name: "{{NAME}}"
category: "{{CATEGORY}}"           # e.g., Linked List / Array / DP
aliases: []                        # optional alternative names
related: []                        # other technique names
---

# {{NAME}}

## 簡介
（這個技巧在做什麼、解什麼痛點？）

## 何時使用
- 場景 1
- 場景 2

## 步驟
1. ...
2. ...
3. ...

## 常見坑
- ...
- ...

## 範例程式（可選）
```cpp
// example snippet
```

## 延伸閱讀（可選）
- 連結 or 註解