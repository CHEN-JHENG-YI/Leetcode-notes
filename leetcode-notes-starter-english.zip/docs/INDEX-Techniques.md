# INDEX — Techniques

## Array Rebuild
**Problems using this technique:**
- [2074] [Reverse Nodes in Even Length Groups](2074-Reverse-Nodes-in-Even-Length-Groups.md)

## Dummy Head  _(Category: Linked List)_
[Technique Page](TECHNIQUES-Linked-List.md#dummy-head)
**Problems using this technique:**
- [2074] [Reverse Nodes in Even Length Groups](2074-Reverse-Nodes-in-Even-Length-Groups.md)

## Group Reversal  _(Category: Linked List)_
[Technique Page](TECHNIQUES-Linked-List.md#group-reversal)
**Problems using this technique:**
- [2074] [Reverse Nodes in Even Length Groups](2074-Reverse-Nodes-in-Even-Length-Groups.md)

## {{NAME}}  _(Category: "{{CATEGORY}}"           # e.g., Linked List / Array / DP)_
[Technique Page](techniques/_TEMPLATE_TECHNIQUE.md)
_No problems tagged yet._
