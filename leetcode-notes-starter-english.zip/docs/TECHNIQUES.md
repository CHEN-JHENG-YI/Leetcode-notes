# TECHNIQUES（總表）

將常用技巧分主題維護（可自行新增檔案）：
- `techniques_linked_list.md`
- `techniques_tree.md`
- `techniques_array.md`
- ...

> 你可以在每題筆記的 YAML front-matter 中填 `topics` 與 `techniques`，然後執行 `python generate_index.py` 自動生成索引。