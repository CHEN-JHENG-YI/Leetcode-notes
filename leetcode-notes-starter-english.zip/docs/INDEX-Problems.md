# INDEX — Problems

| ID | Title | Topics | Techniques | Difficulty | Note |
|---:|-------|--------|------------|------------|------|
| 2074 | [Reverse Nodes in Even Length Groups](2074-Reverse-Nodes-in-Even-Length-Groups.md) | Linked List | Dummy Head, Group Reversal, Array Rebuild | Medium | |