# INDEX — Techniques by Category

## "{{CATEGORY}}"           # e.g., Linked List / Array / DP
- [{{NAME}}](techniques/_TEMPLATE_TECHNIQUE.md)

## Linked List
- [Dummy Head](TECHNIQUES-Linked-List.md#dummy-head)
- [Group Reversal](TECHNIQUES-Linked-List.md#group-reversal)
